A file per language.

If you want to work with a language which is not already  managed here, you need to add a new file for this language by following the standard ISO639-1 on 2 letters.

edc can support up to 36 languages with codes :

  'en', // English

  'ar', // Arabic

  'bg', // Bulgarian

  'zh', // Chinese

  'hr', // Croatian

  'cs', // Czech

  'da', // Danish

  'nl', // Dutch

  'et', // Estonian

  'fi', // Finnish

  'fr', // French

  'de', // German

  'el', // Greek

  'he', // Hebrew

  'hu', // Hungarian

  'is', // Icelandic

  'ga', // Irish

  'it', // Italian

  'ja', // Japanese

  'ko', // Korean

  'lv', // Latvian

  'lt', // Lithuanian

  'lb', // Luxembourgish

  'mt', // Maltese

  'no', // Norwegian

  'fa', // Persian

  'pl', // Polish

  'pt', // Portuguese

  'ro', // Romanian

  'ru', // Russian

  'sk', // Slovak

  'sl', // Slovenian

  'es', // Spanish

  'sv', // Swedish

  'tr', // Turkish

  'vi', // Vietnamese
